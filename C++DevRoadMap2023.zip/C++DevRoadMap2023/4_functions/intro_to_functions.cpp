/**

Software Engineer: Roger De Four
Description - I am always constantly switch my job title
Now as I am into C++ again _ that makes me an engigerr IKR .... LOL 


Learning from the C++ dev Roadmap


**/

#include <iostream>
int addnumbers(int num1 , int num2) {
	
	int sum = num1 + num2 ;
	
	return sum;
}



int main () {
	
	
		int  a = 10 , b  = 16 ;
		int result = addnumbers(a , b) ;
		std::cout << "The sum is: "  <<  result << std::endl ;
	return 0;
	
}