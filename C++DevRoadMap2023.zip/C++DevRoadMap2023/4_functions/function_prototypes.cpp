/**


Software Engineer : Roger De Four
Date: 2024-07-21 15:32
Description: Here I am reviewing function prototypes - a declaration before the function is defined


**/


#include <iostream>

// function prototype

int mulNum(int a , int b) ;


int main () {
	
	int num1 = 15 , num2 = 26 ;
	
	int result = mulNum(num1 , num2) ;
	
 std::cout << "The multiplation result is: "	 <<  result <<std::endl; 
 
 
 
 
	
	return 0;
	
}

int mulNum(int a , int b) {
	
	int res = a * b ;
	
	return res ;


}