/*
IT Consultant: ROger De Four
Date: 2023-09-02 07:27
Decription - my burning intereste in C/C++ and also that I can use it in Forex, either as stand alone or under guise of MQL5
			is always pulling me towards mastering this in my softwaeengineering toolkit
			
**/

#include <iostream>

// A simple function to add two numbers
int add(int a, int b) {
    return a + b;
}

class Calculator {
public:
    // A member function to multiply two numbers
    int multiply(int a, int b) {
        return a * b;
    }
};

int main() {
    int x = 5;
    int y = 3;

    // Using the standalone function 'add'
    int sum = add(x, y);
    std::cout << "Sum: " << sum << std::endl;

    // Using a class and member function
    Calculator calc;
    int product = calc.multiply(x, y);
    std::cout << "Product: " << product << std::endl;

    return 0;
}